const TravelAgent = () => {
    return(
        <>
            TravelAgent
        </>
    )
}

export default TravelAgent;