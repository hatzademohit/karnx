const GHS = () => {
    return(
        <>
            GHS
        </>
    )
}

export default GHS;